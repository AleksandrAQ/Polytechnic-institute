/*
 * Авферонок Александр в3530904/80022
 *
 * Задание к лабораторной работе. Необходимо выполнить ВСЕ задания.
 * 1) Напишите алгоритм сортировки (любой простейший) содержимого вектора целых чисел, используя оператор operator[].
 * 2) Напишите алгоритм сортировки (любой простейший) содержимого вектора целых чисел, используя метод at().
 * 3) Напишите алгоритм сортировки (любой простейший) содержимого вектора целых чисел, используя для доступа к
 *    содержимому вектора только итераторы. Для работы с итераторами допустимо использовать только операторы получения текущего элемента
 *    и перехода в следующему (подсказка, можно сохранять копию итератора указывающего на некоторый элемент).
 * 4) Прочитайте во встроенный массив С содержимое текстового файлы, скопируйте данные в вектор одной строкой кода (без циклов и алгоритмов STL)
 * 5) Напишите программу, сохраняющую в векторе числа, полученные из стандартного ввода (окончанием ввода является число 0).
 *    Удалите все элементы, которые делятся на 2 (не используете стандартные алгоритмы STL), если последнее число 1.
 *    Если последнее число 2, добавьте после каждого числа которое делится на 3 три единицы.
 * 6) Напишите функцию void fillRandom(double* array, int size) заполняющую массив случайными значениями в интервале от -1.0 до 1.0.
 *    Заполните с помощью заданной функции вектора размером 5,10,25,50,100 и отсортируйте его содержимое
 *    (с помощью любого разработанного ранее алгоритма модифицированного для сортировки действительных чисел)
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <stdio.h>
#include <time.h>

using namespace std;

/*!
 *  \brief vectorRand заполненяет вектор случайными значениями от -1.0 до 1.0.
 */
template<typename T>
void vectorRand(vector<T> &vec){
    for (unsigned int i = 0; i < vec.size(); i++) {
        int num = rand() % 201 - 100;
        vec[i] = static_cast<double>(num)/100;
    }
}

/*!
 *  \brief vectorPrint выводит содержимое вектора в стандартый поток вывода.
 */
template<typename T>
void vectorPrint(vector<T> &vec){
    for (auto number : vec) {
        cout << number<<" ";
    }
    cout << endl;
}

/*!
 *  \brief bubbleSprtOperator сортирует вектор пузырьком используя оператор [].
 */
template<typename T>
void bubbleSprtOperator(vector<T> &vec){
    for (unsigned int i = 0; i < vec.size()-1; i++) {
        for (unsigned int j = 0; j < vec.size() - i-1; j++) {
            if (vec[j] > vec[j + 1]) {
                swap(vec[j],vec[j+1]);
            }
        }
    }
}

/*!
 *  \brief bubbleSortAt сортирует вектор пузырьком используя метод at().
 */
template<typename T>
void bubbleSortAt(vector<T> &vec){
    for (unsigned int i = 0; i < vec.size()-1; i++) {
        for (unsigned int j = 0; j < vec.size() - i-1; j++) {
            if (vec.at(j) > vec.at(j+1)) {
                swap(vec.at(j),vec.at(j+1));
            }
        }
    }
}

/*!
 *  \brief bubbleSortIterator сортирует вектор пузырьком используя итераторы.
 */
template <class Iterator>
void bubbleSortIterator(Iterator begin, Iterator end) {
    for (Iterator i = begin; i != end; ++i)
        for (Iterator j = begin; j < i; ++j)
            if (*i < *j)
                swap(*i, *j);
}

/*!
 *  \brief readFromFile чтение файла input.txt в массиф.
 */
void readFromFile(){
    cout << "Чтение из файла.." << endl;
    ifstream input;
    input.open("input.txt");
    input.seekg(0, input.end);
    long length = input.tellg();
    input.seekg(0, input.beg); // перенос коретки в началок
    char buf[length];
    input.read(buf, length);
    input.close();
    vector<char> vec;
    vec.assign(buf, &buf[sizeof(buf)]);  // пересоздание вектора с новыми данными
    cout << "Данные:";
    vectorPrint(vec);
    cout << endl;
}

/*!
 *  \brief создание вектора из стандартного потока ввода и обработка данных.
 */
void readInput(){
    vector<double> vec;
    vector<double> vecTmp;
    int number=1;
    do{
        cin >> number;
        vec.push_back(number);

    }while (number!=0);
    vec.pop_back();
    vectorPrint(vec);
    if(static_cast<int>(*--vec.end()) == 1){
        vec.pop_back();
        for (auto number : vec) {
            if(static_cast<int>(number)%2!=0){
                vecTmp.push_back(number);
            }
        }
    }
    if(static_cast<int>(*--vec.end()) == 2){
        vec.pop_back();
        for (auto number : vec) {
            vecTmp.push_back(number);
            if(static_cast<int>(number)%3==0){
                vecTmp.push_back(1);
                vecTmp.push_back(1);
                vecTmp.push_back(1);
            }
        }
    }
    vectorPrint(vecTmp);
}

int main()
{
    /*
     * Задание 1
    */
    vector<double> vec(90000);
    vectorRand(vec);
    ///cout << "Исходный вектор:";
    ///vectorPrint(vec);
    clock_t t1 = clock();
    bubbleSprtOperator(vec);
    t1 = clock() - t1;
    cout << "Отсортированный через оператор [] затратила "<<(static_cast<double>(t1))/CLOCKS_PER_SEC<<endl;
    ///vectorPrint(vec);
    /*
     * Задание 2
    */
    vectorRand(vec);
    ///cout << "Исходный вектор:";
    ///vectorPrint(vec);
    clock_t t2 = clock();
    bubbleSortAt(vec);
    t2 = clock() - t2;
    cout << "Отсортированный через at затратила "<<(static_cast<double>(t1))/CLOCKS_PER_SEC<<endl;
    ///vectorPrint(vec);
    /*
     * Задание 3
    */
    vectorRand(vec);
    ///cout << "Исходный вектор:";
    ///vectorPrint(vec);
    clock_t t3 = clock();
    bubbleSortIterator(vec.begin(), vec.end());
    t3 = clock() - t3;
    cout << "Отсортированный через iter затратила "<<(static_cast<double>(t3))/CLOCKS_PER_SEC<<endl;
    ///vectorPrint(vec);
    /*
     * Задание 4
     */
    readFromFile();
    /*
     * Задание 5
     */
    readInput();
    return 0;
}
