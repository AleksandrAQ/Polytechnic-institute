# Импортируем все необходимые библиотеки:
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from PIL import Image as Image
import numpy
import sys

# Объявляем все глобальные переменные
global xrot         # Величина вращения по оси x
global yrot         # Величина вращения по оси y
global ambient      # рассеянное освещение
global greencolor   # Цвет елочных иголок
global teapotcolor    # Цвет елочного стебля
global bluecolor
global lightpos     # Положение источника освещения
global drowmode  # для перемещение чаника и цилиндра
global drowmode2 # для перемещения тора и конуса
global laba1  # выблор какой лабы показывать чайник
global laba2  # тор
global xlig
global ylig
global zlig

# Процедура инициализации
def init():
    global xrot         # Величина вращения по оси x
    global yrot         # Величина вращения по оси y
    global ambient      # Рассеянное освещение
    global greencolor   # Цвет елочных иголок
    global teapotcolor    # Цвет елочного ствола
    global lightpos     # Положение источника освещения
    global xlig
    global ylig
    global zlig
    global drowmode
    global drowmode2
    global laba1
    global laba2
    global bluecolor

    laba1 = True # первоначальная инициализация отрисовывающейся лабы
    laba2 = False
    drowmode = False
    drowmode2 = False

    xlig = 1.0
    ylig = 1.0
    zlig = 1.0

    xrot = 0.0                          # Величина вращения по оси x = 0
    yrot = 0.0                          # Величина вращения по оси y = 0
    ambient = (1.0, 1.0, 1.0, 1)        # Первые три числа цвет в формате RGB, а последнее - яркость
    bluecolor = (0, 0.3, 0.6, 0)  # Зеленый цвет для иголок
    greencolor = (0.2, 0.8, 0.0, 0.8)   # Зеленый цвет для иголок
    teapotcolor = (0.9, 0.1, 0.1, 1)    # красный цвет для чайника
    lightpos = (1.0, 1.0, 1.0)          # Положение источника освещения по осям xyz

    glClearColor(0.5, 0.5, 0.5, 1.0)                # Серый цвет для первоначальной закраски
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0)                # Определяем границы рисования по горизонтали и вертикали
    glRotatef(-90, 1.0, 0.0, 0.0)                   # Сместимся по оси Х на 90 градусов
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient) # Определяем текущую модель освещения
    glEnable(GL_LIGHTING)                           # Включаем освещение
    glEnable(GL_LIGHT0)                             # Включаем один источник света
    glLightfv(GL_LIGHT0, GL_POSITION, lightpos)     # Определяем положение источника света


# Процедура обработки специальных клавиш
def specialkeys(key, x, y):
    global ambient
    global xrot
    global yrot
    global laba1
    global laba2
    global drowmode
    global drowmode2
    global lightpos
    global xlig
    global ylig
    global zlig

    # Обработчики для клавиш со стрелками

    if key == GLUT_KEY_UP:      # Клавиша вверх
        xrot -= 2.0             # Уменьшаем угол вращения по оси Х
    if key == GLUT_KEY_DOWN:    # Клавиша вниз
        xrot += 2.0             # Увеличиваем угол вращения по оси Х
    if key == GLUT_KEY_LEFT:    # Клавиша влево
        yrot -= 2.0             # Уменьшаем угол вращения по оси Y
    if key == GLUT_KEY_RIGHT:   # Клавиша вправо
        yrot += 2.0             # Увеличиваем угол вращения по оси Y
    if key == GLUT_KEY_HOME: # если нажата кнопка home будет отриосываться чаник и цилиндр
        drowmode = True
        laba1 = True
        laba2 = False
    if key == GLUT_KEY_INSERT: # если нажата кнопка insert чайник отрисуется на цилиндре
        drowmode = False
        laba1=True
        laba2=False
    if key == GLUT_KEY_PAGE_UP: # если нажата кнопка page up будет отрисован тор и конус
        drowmode2 = True
        laba1 = False
        laba2 = True
    if key == GLUT_KEY_PAGE_DOWN: # если нажата кнопка page up будет отрисован тор и конус
        drowmode2 = False
        laba1 = False
        laba2 = True

    if key == 1:      # Клавиша вверх
        xlig += 2.0
    if key == 2:      # Клавиша вверх
        xlig -= 2.0
    if key == 3:      # Клавиша вверх
        ylig += 2.0
    if key == 4:      # Клавиша вверх
        ylig -= 2.0
    if key == 5:      # Клавиша вверх
        zlig += 2.0
    if key == 6:  # Клавиша вверх
        zlig -= 2.0
    if key == 7:  # Клавиша вверх
        ambient = (0.0, 0.0, 0.0, 1)
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient)
    if key == 8:  # Клавиша вверх
        ambient = (1.0, 1.0, 1.0, 1)
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient)
    if key == 9:  # Клавиша вверх
        ambient = (1.0, 1.0, 1.0, 0)
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient)
    if key == 10:  # Клавиша вверх
        ambient = (1.0, 0.0, 0.0, 1)
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient)
    if key == 11:  # Клавиша вверх
        ambient = (0.0, 1.0, 1.0, 1)
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient)
    if key == 12:  # Клавиша вверх
        tex = read_texture('p.jpg')
        qobj = gluNewQuadric()
        gluQuadricTexture(qobj, GL_TRUE)
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, tex)
        glBegin(GL_TRIANGLES)
        # gluSphere(qobj, 1, 50, 50)
        gluDeleteQuadric(qobj)
        glDisable(GL_TEXTURE_2D)

    lightpos = (xlig, ylig, zlig)

    glutPostRedisplay()         # Вызываем процедуру перерисовки

def read_texture(filename):
    img = Image.open(filename)
    img_data = numpy.array(list(img.getdata()), numpy.int8)
    textID = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, textID)  # This is what's missing
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img.size[0], img.size[1], 0, GL_RGB, GL_UNSIGNED_BYTE, img_data)
    return textID

# Процедура перерисовки
def draw():
    global xrot
    global yrot
    global laba1
    global laba2
    global lightpos
    global greencolor
    global teapotcolor
    global drowmode
    global drowmode2
    global xlig
    global ylig
    global zlig
    global bluecolor


    glClear(GL_COLOR_BUFFER_BIT)                                # Очищаем экран и заливаем серым цветом
    glPushMatrix()                                              # Сохраняем текущее положение "камеры"
    glRotatef(xrot, 1.0, 0.0, 0.0)                              # Вращаем по оси X на величину xrot
    glRotatef(yrot, 0.0, 1.0, 0.0)                              # Вращаем по оси Y на величину yrot
    glLightfv(GL_LIGHT0, GL_POSITION, lightpos)                 # Источник света вращаем вместе с елкой
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);

    if(laba1): # тут основное рисование чайник и целиндр
        if(drowmode):# отрисует одно
            color = (1, 0, 0, 0.0) # 1 прозрачный
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE , 128)
            glutSolidTeapot(0.5)
        else:# отрисует другое
            color = (0, 0, 1, 0.9)
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE  , color)
            glutSolidCylinder(0.1, 0.2, 20, 20)
            color = (1, 0, 0, 0)
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE  , color)
            glTranslatef(0.0, 0.0, -0.7)
            glutSolidCylinder(0.1, 0.2, 20, 20)


    if(laba2): # тор и конус
        if (drowmode2): # отрисует одно
            color = (0, 0, 0, 0.0)
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS , 128,5)
            glutSolidTorus(0.4, 0.8, 60, 60)
        else:# отрисует другое
            color = (0, 1, 0, 0.0)
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE , color)
            glutSolidCone(0.625, 0.625, 20, 20)
    # Рисуем ствол елки
    # Устанавливаем материал: рисовать с 2 сторон, рассеянное освещение, коричневый цвет
    ##glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, treecolor)
    ##glTranslatef(0.0, 0.0, -0.7)                                # Сдвинемся по оси Z на -0.7
    # Рисуем цилиндр с радиусом 0.1, высотой 0.2
    # Последние два числа определяют количество полигонов
    ##glutSolidCylinder(0.1, 0.2, 20, 20)
    # Рисуем ветки елки
    # Устанавливаем материал: рисовать с 2 сторон, рассеянное освещение, зеленый цвет
    ##glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, greencolor)
    ##glTranslatef(0.0, 0.0, 0.2)                                 # Сдвинемся по оси Z на 0.2
    # Рисуем нижние ветки (конус) с радиусом 0.5, высотой 0.5
    # Последние два числа определяют количество полигонов
    ##glutSolidCone(0.5, 0.5, 20, 20)
    ##glTranslatef(0.0, 0.0, 0.3)                                 # Сдвинемся по оси Z на -0.3
    ##glutSolidCone(0.4, 0.4, 20, 20)                             # Конус с радиусом 0.4, высотой 0.4
    ##glTranslatef(0.0, 0.0, 0.3)                                 # Сдвинемся по оси Z на -0.3
    ##glutSolidCone(0.3, 0.3, 20, 20)                             # Конус с радиусом 0.3, высотой 0.3

    glPopMatrix()                                               # Возвращаем сохраненное положение "камеры"
    glutSwapBuffers()                                           # Выводим все нарисованное в памяти на экран


# Здесь начинается выполнение программы
# Использовать двойную буферизацию и цвета в формате RGB (Красный, Зеленый, Синий)
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB)
# Указываем начальный размер окна (ширина, высота)
glutInitWindowSize(300, 300)
# Указываем начальное положение окна относительно левого верхнего угла экрана
glutInitWindowPosition(50, 50)
# Инициализация OpenGl
glutInit(sys.argv)
# Создаем окно с заголовком "Happy New Year!"
glutCreateWindow(b"teapot!")
# Определяем процедуру, отвечающую за перерисовку
glutDisplayFunc(draw)
# Определяем процедуру, отвечающую за обработку клавиш
glutSpecialFunc(specialkeys)
# Вызываем нашу функцию инициализации
init()
# Запускаем основной цикл
glutMainLoop()